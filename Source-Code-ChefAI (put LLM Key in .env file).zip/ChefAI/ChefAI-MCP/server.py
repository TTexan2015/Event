"""ChefAI MCP server (STDIO). Run: python ChefAI-MCP/server.py  (or --demo for a local smoke test)."""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from tools import csv_tools, invoice_tools, llm_tools  # noqa: E402


def query_expenses(period: str, item: str | None = None) -> dict:
    """Query expenses from the CSV for a period: latest_delivery, year_to_date, last_year or a 4-digit year in the CSV.

    The optional item is a case-insensitive substring, e.g. tomato matches Roma tomatoes; loaf matches
    Sourdough loaves. Simple singular/plural forms also match. Returns aggregated items, grand_total,
    matched_row_count and distinct vendor_count.
    """
    return csv_tools.query_expenses(period, item)


def generate_invoice(period: str) -> dict:
    """Write an HTML expense invoice for latest_delivery, year_to_date or last_year (a 4-digit year in the CSV also works) and return the file path."""
    return invoice_tools.generate_invoice(period)


def generate_report(title: str, mode: str = "summary", queries: list[dict] | None = None) -> dict:
    """Write a custom HTML report from the query_expenses results so far and return the file path.

    mode is summary, compare (two or more periods side by side by item), qty_price (qty, average price and spend
    by item) or vendor. Optionally pass queries as [{"period": "...", "item": "..."}] instead of using earlier results.
    """
    return invoice_tools.generate_report(title, mode, queries)


def chef_summary(text: str) -> str:
    """Ask the configured LLM for a two-sentence chef-style summary of the given text; use only numbers in that text."""
    try:
        return llm_tools.call_llm(
            "In two sentences, say what a chef would say about the following. Use only numbers that appear in it.\n\n" + text
        ).strip()
    except Exception as exc:
        return f"LLM error: {exc}"


TOOL_FUNCTIONS = [query_expenses, generate_invoice, generate_report, chef_summary]


def run_demo():
    print("ChefAI MCP demo")
    print("CSV:", csv_tools.get_csv_path())
    for call in (
        lambda: csv_tools.query_expenses("last_year", "tomato"),
        lambda: invoice_tools.generate_invoice("latest_delivery"),
    ):
        print(json.dumps(call(), indent=2, default=str))


def main():
    if "--demo" in sys.argv:
        run_demo()
        return
    try:
        from mcp.server.mcpserver import MCPServer as Server  # mcp 2.x
    except ImportError:
        from mcp.server.fastmcp import FastMCP as Server  # mcp 1.x

    server = Server(csv_tools.PROJECT, log_level="WARNING")
    for func in TOOL_FUNCTIONS:
        server.tool()(func)
    server.run(transport="stdio")


if __name__ == "__main__":
    main()
