"""CSV discovery, period mapping and expense queries for the ChefAI MCP server."""
import calendar
import csv
import os
import re
from datetime import date
from pathlib import Path

MCP_DIR = Path(__file__).resolve().parents[1]
PROJECT_ROOT = Path(__file__).resolve().parents[2]
PROJECT = PROJECT_ROOT.name
REQUIRED_COLUMNS = {"date", "item", "vendor", "qty", "unit_price"}

# First the folder one level above the project (sibling data folder), then the project root.
SEARCH_DIRS = [PROJECT_ROOT.parent, PROJECT_ROOT]

_ROW_CACHE = {}
_LAST_RESULTS = []


def is_usable_csv(path):
    try:
        with open(path, newline="", encoding="utf-8-sig") as handle:
            header = next(csv.reader(handle), [])
    except (OSError, UnicodeDecodeError):
        return False
    return REQUIRED_COLUMNS.issubset({h.strip().lower() for h in header})


def find_csvs():
    """Return (folder_that_worked_or_None, usable csv paths, every folder searched)."""
    searched = []
    for folder in SEARCH_DIRS:
        searched.append(str(folder))
        files = [p for p in sorted(folder.glob("*.csv")) if is_usable_csv(p)]
        if files:
            return folder, files, searched
    return None, [], searched


def get_csv_path():
    chosen = os.getenv("CHEFAI_CSV_PATH")
    if chosen and Path(chosen).is_file():
        return Path(chosen)
    _, files, _ = find_csvs()
    return files[0] if files else None


def no_csv_error():
    _, _, searched = find_csvs()
    return {
        "error": "No CSV file with columns date,item,vendor,qty,unit_price was found.",
        "searched": searched,
    }


def load_rows(path):
    path = Path(path)
    stamp = (str(path), path.stat().st_mtime)
    if stamp in _ROW_CACHE:
        return _ROW_CACHE[stamp]
    rows = []
    with open(path, newline="", encoding="utf-8-sig") as handle:
        for raw in csv.DictReader(handle):
            raw = {(k or "").strip().lower(): (v or "").strip() for k, v in raw.items()}
            try:
                rows.append(
                    {
                        "date": date.fromisoformat(raw["date"]),
                        "item": raw["item"],
                        "vendor": raw["vendor"],
                        "qty": float(raw["qty"]),
                        "unit_price": float(raw["unit_price"]),
                    }
                )
            except (KeyError, ValueError):
                continue
    _ROW_CACHE[stamp] = rows
    return rows


def csv_info(path=None):
    path = Path(path) if path else get_csv_path()
    if path is None:
        return None
    rows = load_rows(path)
    dates = [r["date"] for r in rows]
    step = max(1, len(rows) // 3)
    return {
        "csv_path": str(path),
        "columns": sorted(REQUIRED_COLUMNS),
        "row_count": len(rows),
        "min_date": min(dates).isoformat() if dates else None,
        "max_date": max(dates).isoformat() if dates else None,
        "years_present": sorted({d.year for d in dates}),
        "sample_rows": [{**r, "date": r["date"].isoformat()} for r in rows[::step][:3]],
        "items": sorted({r["item"] for r in rows}),
        "vendors": sorted({r["vendor"] for r in rows}),
    }


def _qty(value):
    return int(value) if float(value).is_integer() else round(value, 3)


def resolve_period(period, rows):
    """Map a period token to {key, label, start, end}. Years come from the CSV, never hardcoded."""
    if not rows:
        raise ValueError("The CSV has no usable rows.")
    dates = [r["date"] for r in rows]
    min_d, max_d = min(dates), max(dates)
    years = sorted({d.year for d in dates})
    latest_year = max_d.year
    text = str(period or "").strip().lower()
    if not text:
        raise ValueError("period is required (latest_delivery, year_to_date, last_year or a 4-digit year).")
    token = re.sub(r"[\s\-]+", "_", text)

    def ytd(year):
        start = date(year, 1, 1)
        return {"key": "year_to_date", "label": f"Year to date ({start.isoformat()} to {max_d.isoformat()})", "start": start, "end": max_d}

    def full_year(year, key, label):
        return {"key": key, "label": label, "start": date(year, 1, 1), "end": date(year, 12, 31)}

    if token in {"latest_delivery", "latest", "most_recent", "most_recent_delivery", "last_delivery"}:
        return {"key": "latest_delivery", "label": f"Latest delivery ({max_d.isoformat()})", "start": max_d, "end": max_d}
    if token in {"year_to_date", "ytd", "this_year", "current_year"}:
        return ytd(latest_year)
    if token in {"last_year", "previous_year", "prior_year", "last_calendar_year"}:
        return full_year(latest_year - 1, "last_year", f"Last year ({latest_year - 1})")
    if token in {"all", "all_time", "everything", "all_dates"}:
        return {"key": "all_time", "label": f"All dates ({min_d.isoformat()} to {max_d.isoformat()})", "start": min_d, "end": max_d}

    year_match = re.fullmatch(r"(?:all_of_|full_year_|calendar_year_|year_)?(\d{4})", token)
    if year_match:
        year = int(year_match.group(1))
        if year not in years:
            raise ValueError(f"Year {year} is not in the CSV (years present: {', '.join(map(str, years))}).")
        if year == latest_year:
            return ytd(year)
        if year == latest_year - 1:
            return full_year(year, "last_year", f"Last year ({year})")
        return full_year(year, f"year_{year}", f"Calendar year {year}")

    range_match = re.fullmatch(r"(\d{4}-\d{2}-\d{2})\s*(?:\.\.|to)\s*(\d{4}-\d{2}-\d{2})", text)
    try:
        if range_match:
            start, end = date.fromisoformat(range_match.group(1)), date.fromisoformat(range_match.group(2))
            if end < start:
                start, end = end, start
            return {"key": f"range_{start}_{end}", "label": f"{start.isoformat()} to {end.isoformat()}", "start": start, "end": end}
        if re.fullmatch(r"\d{4}-\d{2}-\d{2}", text):
            day = date.fromisoformat(text)
            return {"key": f"day_{day}", "label": day.isoformat(), "start": day, "end": day}
        month_match = re.fullmatch(r"(\d{4})-(\d{2})", text)
        if month_match:
            year, month = int(month_match.group(1)), int(month_match.group(2))
            start = date(year, month, 1)
            end = date(year, month, calendar.monthrange(year, month)[1])
            return {"key": f"month_{year}_{month:02d}", "label": f"{year}-{month:02d}", "start": start, "end": end}
    except ValueError as exc:
        raise ValueError(f"Invalid date in period '{period}': {exc}")

    raise ValueError(
        f"Unknown period '{period}'. Use latest_delivery, year_to_date, last_year, a 4-digit year "
        f"present in the CSV ({', '.join(map(str, years))}), YYYY-MM, YYYY-MM-DD or YYYY-MM-DD..YYYY-MM-DD."
    )


def _forms(word):
    """Singular candidates for a word (loaves -> loaf, tomatoes -> tomato)."""
    word = word.lower()
    forms = {word}
    if len(word) > 3 and word.endswith("ves"):
        forms.update({word[:-3] + "f", word[:-3] + "fe", word[:-1]})
    if len(word) > 3 and word.endswith("ies"):
        forms.update({word[:-3] + "y", word[:-1]})
    if len(word) > 3 and word.endswith("es"):
        forms.update({word[:-2], word[:-1]})
    if len(word) > 2 and word.endswith("s") and not word.endswith("ss"):
        forms.add(word[:-1])
    return forms


def item_matches(item_name, item_filter):
    """Case-insensitive substring match with simple singular/plural handling."""
    wanted = (item_filter or "").strip().lower()
    if not wanted:
        return True
    name = item_name.lower()
    if wanted in name:
        return True
    item_words = re.findall(r"[a-z0-9]+", name)
    for word in re.findall(r"[a-z0-9]+", wanted):
        word_forms = _forms(word)
        if not any(word in iw or word_forms & _forms(iw) for iw in item_words):
            return False
    return True


def run_query(period, item=None):
    path = get_csv_path()
    if path is None:
        return no_csv_error()
    rows = load_rows(path)
    info = csv_info(path)
    try:
        span = resolve_period(period, rows)
    except ValueError as exc:
        return {
            "error": str(exc),
            "csv_path": info["csv_path"],
            "min_date": info["min_date"],
            "max_date": info["max_date"],
            "years_present": info["years_present"],
        }
    item_filter = (item or "").strip() or None
    matched = [
        r for r in rows if span["start"] <= r["date"] <= span["end"] and item_matches(r["item"], item_filter)
    ]

    by_item, by_vendor = {}, {}
    for r in matched:
        line = r["qty"] * r["unit_price"]
        entry = by_item.setdefault(r["item"], {"vendors": set(), "qty": 0.0, "total": 0.0})
        entry["vendors"].add(r["vendor"])
        entry["qty"] += r["qty"]
        entry["total"] += line
        v = by_vendor.setdefault(r["vendor"], {"qty": 0.0, "total": 0.0})
        v["qty"] += r["qty"]
        v["total"] += line

    items = [
        {
            "item": name,
            "vendor": ", ".join(sorted(e["vendors"])),
            "total_qty": _qty(e["qty"]),
            "avg_unit_price": round(e["total"] / e["qty"], 2) if e["qty"] else 0.0,
            "line_total": round(e["total"], 2),
        }
        for name, e in sorted(by_item.items())
    ]
    vendors = [
        {"vendor": name, "total_qty": _qty(v["qty"]), "line_total": round(v["total"], 2)}
        for name, v in sorted(by_vendor.items())
    ]
    result = {
        "error": None,
        "csv_path": info["csv_path"],
        "row_count": info["row_count"],
        "min_date": info["min_date"],
        "max_date": info["max_date"],
        "period": span["key"],
        "period_input": str(period),
        "period_label": span["label"],
        "date_start": span["start"].isoformat(),
        "date_end": span["end"].isoformat(),
        "item_filter": item_filter,
        "matched_row_count": len(matched),
        "items": items,
        "grand_total": round(sum(e["total"] for e in by_item.values()), 2),
        "total_qty": _qty(sum(e["qty"] for e in by_item.values())),
        "vendor_count": len(by_vendor),
        "vendors": vendors,
    }
    if not matched:
        result["note"] = "No rows matched this period and item filter."
    return result


def query_expenses(period, item=None):
    """Query the expense CSV for a period and optionally one item; remembers the result for generate_report."""
    result = run_query(period, item)
    if not result.get("error"):
        _LAST_RESULTS.append(result)
    return result


def take_last_results(clear=True):
    results = list(_LAST_RESULTS)
    if clear:
        _LAST_RESULTS.clear()
    return results


def csv_summary(path=None):
    """Row counts for the terminal: file totals plus latest delivery, YTD and last year."""
    path = Path(path) if path else get_csv_path()
    if path is None:
        return None
    rows = load_rows(path)
    info = csv_info(path)
    counts = {}
    for key in ("latest_delivery", "year_to_date", "last_year"):
        span = resolve_period(key, rows)
        counts[key] = sum(1 for r in rows if span["start"] <= r["date"] <= span["end"])
    return {**info, "period_row_counts": counts}
