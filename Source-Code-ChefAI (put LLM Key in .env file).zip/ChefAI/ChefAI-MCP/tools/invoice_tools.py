"""HTML invoice and report writers for the ChefAI MCP server."""
import html
import re
from datetime import datetime

from . import csv_tools

TEMPLATE_PATH = csv_tools.MCP_DIR / "templates" / "invoice.html"
OUTPUT_DIR = csv_tools.MCP_DIR / "output"
INVOICES_DIR = csv_tools.PROJECT_ROOT / "invoices"
PROJECT = csv_tools.PROJECT


def _money(value):
    return f"${value:,.2f}"


def _esc(value):
    return html.escape(str(value))


def _slug(text, limit=60):
    return re.sub(r"[^a-z0-9]+", "_", str(text).lower()).strip("_")[:limit] or "report"


def _table(headers, rows, numeric, total_row=None):
    head = "".join(f'<th class="num">{_esc(h)}</th>' if i in numeric else f"<th>{_esc(h)}</th>" for i, h in enumerate(headers))

    def cells(row, css=""):
        return "".join(
            f'<td class="num">{_esc(c)}</td>' if i in numeric else f"<td>{_esc(c)}</td>" for i, c in enumerate(row)
        )

    body = "".join(f"<tr>{cells(r)}</tr>" for r in rows)
    if total_row:
        body += f'<tr class="total">{cells(total_row)}</tr>'
    return f"<table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table>"


def _items_table(result):
    rows = [
        [i["item"], i["vendor"], i["total_qty"], _money(i["avg_unit_price"]), _money(i["line_total"])]
        for i in result["items"]
    ]
    total = ["TOTAL", "", result["total_qty"], "", _money(result["grand_total"])]
    return _table(["Item", "Vendor", "Qty", "Unit price (avg)", "Line total"], rows, {2, 3, 4}, total)


def _qty_price_table(result):
    rows = [[i["item"], i["total_qty"], _money(i["avg_unit_price"]), _money(i["line_total"])] for i in result["items"]]
    total = ["TOTAL", result["total_qty"], "", _money(result["grand_total"])]
    return _table(["Item", "Total qty", "Average unit price", "Total spend"], rows, {1, 2, 3}, total)


def _vendor_table(result):
    rows = [[v["vendor"], v["total_qty"], _money(v["line_total"])] for v in result["vendors"]]
    total = [f"TOTAL ({result['vendor_count']} vendors)", result["total_qty"], _money(result["grand_total"])]
    return _table(["Vendor", "Qty", "Spend"], rows, {1, 2}, total)


def _compare_table(results):
    names = sorted({i["item"] for r in results for i in r["items"]})
    lookup = [{i["item"]: i for i in r["items"]} for r in results]
    headers = ["Item"]
    for r in results:
        headers += [f"{r['period_label']} qty", f"{r['period_label']} spend"]
    headers.append("Difference (last - first)")
    rows = []
    for name in names:
        row = [name]
        for found in lookup:
            entry = found.get(name)
            row += [entry["total_qty"] if entry else 0, _money(entry["line_total"] if entry else 0)]
        first = lookup[0].get(name, {}).get("line_total", 0)
        last = lookup[-1].get(name, {}).get("line_total", 0)
        row.append(_money(last - first))
        rows.append(row)
    total = ["TOTAL"]
    for r in results:
        total += [r["total_qty"], _money(r["grand_total"])]
    total.append(_money(results[-1]["grand_total"] - results[0]["grand_total"]))
    return _table(headers, rows, set(range(1, len(headers))), total)


def _render(kind, number_label, number, period, content, totals):
    template = TEMPLATE_PATH.read_text(encoding="utf-8")
    values = {
        "PROJECT_LOWER": PROJECT.lower(),
        "PROJECT": _esc(PROJECT),
        "DOC_KIND": _esc(kind),
        "NUMBER_LABEL": _esc(number_label),
        "DOC_NUMBER": _esc(number),
        "PERIOD": _esc(period),
        "GENERATED": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "CONTENT": content,
        "TOTALS": totals,
    }
    for name, value in values.items():
        template = template.replace("{{" + name + "}}", value)
    return template


def _write(filename, page):
    paths = []
    for folder in (INVOICES_DIR, OUTPUT_DIR):
        folder.mkdir(parents=True, exist_ok=True)
        target = folder / filename
        target.write_text(page, encoding="utf-8")
        paths.append(str(target))
    return paths


def _failure_page(kind, number, period, filename, failure):
    """Write the attempted CSV paths into HTML so a missing CSV is never shown as 'no shipments'."""
    searched = failure.get("searched") or []
    listing = "".join(f"<li>{_esc(p)}</li>" for p in searched)
    content = (
        f'<p class="note">{_esc(failure["error"])}</p>'
        f"<p>No CSV was loaded. Folders searched for *.csv:</p><ul>{listing}</ul>"
    )
    page = _render(kind, "Number", number, period, content, "")
    invoices_path, output_path = _write(filename, page)
    return {"error": failure["error"], "searched": searched, "file_path": invoices_path, "output_path": output_path}


def _invoice_identity(result):
    key = result["period"]
    year = result["date_end"][:4]
    if key == "latest_delivery":
        return "INV-LATEST", "invoice_latest_delivery.html"
    if key == "year_to_date":
        return f"INV-YTD-{year}", "invoice_year_to_date.html"
    if key == "last_year":
        return f"INV-{year}", "invoice_last_year.html"
    if key.startswith("year_"):
        return f"INV-{year}", f"invoice_{key}.html"
    return f"INV-{_slug(key, 30).upper()}", f"invoice_{_slug(key)}.html"


def generate_invoice(period):
    """Write an HTML expense invoice for latest_delivery, year_to_date, last_year or a 4-digit year; returns the file path."""
    result = csv_tools.run_query(period)
    if result.get("error"):
        if result.get("searched") is not None:
            slug = _slug(period)
            return _failure_page("Expense Invoice", f"INV-{slug.upper()}", str(period), f"invoice_{slug}.html", result)
        return {"error": result["error"], "file_path": None}
    if result["matched_row_count"] == 0:
        return {"error": f"No rows found for {result['period_label']} in {result['csv_path']}.", "file_path": None}

    number, filename = _invoice_identity(result)
    totals = f"<div>Grand total: <strong>{_money(result['grand_total'])}</strong></div>"
    page = _render("Expense Invoice", "Invoice number", number, result["period_label"], _items_table(result), totals)
    invoices_path, output_path = _write(filename, page)
    return {
        "error": None,
        "file_path": invoices_path,
        "output_path": output_path,
        "invoice_number": number,
        "period": result["period"],
        "period_label": result["period_label"],
        "matched_row_count": result["matched_row_count"],
        "grand_total": result["grand_total"],
        "vendor_count": result["vendor_count"],
    }


def _coerce_queries(queries):
    cleaned = []
    for q in queries or []:
        if isinstance(q, str):
            q = {"period": q}
        if isinstance(q, dict):
            q = q.get("arguments", q)
            if q.get("period"):
                cleaned.append({"period": q["period"], "item": q.get("item")})
    return cleaned


def generate_report(title, mode="summary", queries=None):
    """Write a custom HTML report from query results; returns the file path. Modes: summary, compare, qty_price, vendor."""
    title = (str(title or "").strip()) or "Expense report"
    mode = (mode or "summary").strip().lower()
    wanted = _coerce_queries(queries)
    if wanted:
        results = [csv_tools.run_query(q["period"], q["item"]) for q in wanted]
    else:
        results = csv_tools.take_last_results()
    filename = f"report_{_slug(title)}.html"

    if not results:
        return {"error": "No query results available. Call query_expenses first, or pass queries to generate_report.", "file_path": None}
    failures = [r for r in results if r.get("error")]
    if failures:
        if failures[0].get("searched") is not None:
            return _failure_page("Expense Report", f"RPT-{_slug(title, 20).upper()}", title, filename, failures[0])
        return {"error": failures[0]["error"], "file_path": None}
    results = [r for r in results if r["matched_row_count"] > 0]
    if not results:
        return {"error": "No rows matched any of the requested periods or item filters.", "file_path": None}

    sections = []
    if mode == "compare" and len(results) >= 2:
        sections.append(_compare_table(results))
        totals = "".join(
            f"<div>Total — {_esc(r['period_label'])}: <strong>{_money(r['grand_total'])}</strong></div>" for r in results
        )
        diff = results[-1]["grand_total"] - results[0]["grand_total"]
        totals += f"<div>Difference (last - first): <strong>{_money(diff)}</strong></div>"
    else:
        builder = {"qty_price": _qty_price_table, "vendor": _vendor_table}.get(mode, _items_table)
        for r in results:
            suffix = f" — item filter: {r['item_filter']}" if r["item_filter"] else ""
            sections.append(f"<h3>{_esc(r['period_label'] + suffix)}</h3>{builder(r)}")
        totals = "".join(
            f"<div>Grand total — {_esc(r['period_label'])}: <strong>{_money(r['grand_total'])}</strong></div>"
            for r in results
        )

    period = "; ".join(r["period_label"] for r in results)
    filters = sorted({r["item_filter"] for r in results if r["item_filter"]})
    if filters:
        period += f" (item filter: {', '.join(filters)})"
    page = _render(title, "Report number", f"RPT-{_slug(title, 20).upper()}", period, "".join(sections), totals)
    invoices_path, output_path = _write(filename, page)
    return {
        "error": None,
        "file_path": invoices_path,
        "output_path": output_path,
        "title": title,
        "mode": mode,
        "results_used": [
            {
                "period": r["period"],
                "item_filter": r["item_filter"],
                "matched_row_count": r["matched_row_count"],
                "grand_total": r["grand_total"],
            }
            for r in results
        ],
    }
