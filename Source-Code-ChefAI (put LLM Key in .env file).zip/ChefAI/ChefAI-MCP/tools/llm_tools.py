"""LLM routing for the MCP server: openai, anthropic (claude) or groq, via urllib only."""
import json
import os
import re
import urllib.request
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]
PROJECT = PROJECT_ROOT.name

DEFAULT_MODELS = {
    "openai": "gpt-4o-mini",
    "anthropic": "claude-haiku-4-5",
    "groq": "openai/gpt-oss-20b",
}


def load_env_file():
    """Read the single root .env (<project root>/.env); empty values are skipped."""
    try:
        lines = (PROJECT_ROOT / ".env").read_text(encoding="utf-8-sig").splitlines()
    except OSError:
        return
    for line in lines:
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        name, value = line.split("=", 1)
        name, value = name.strip(), value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in ("'", '"'):
            value = value[1:-1]
        if name and value:
            os.environ[name] = value


def normalize_provider(value):
    provider = (value or "").strip().lower()
    if not provider:
        return "openai"
    return "anthropic" if provider == "claude" else provider


def groq_user_agent():
    safe = re.sub(r"[^A-Za-z0-9._-]", "", PROJECT)
    return f"{safe}/1.0" if safe else "PythonApp/1.0"


def call_llm(prompt):
    load_env_file()
    key = os.getenv("LLM_API_KEY")
    if not key:
        raise RuntimeError("LLM_API_KEY is not set in the .env file or the environment.")
    provider = normalize_provider(os.getenv("LLM_PROVIDER"))
    if provider not in DEFAULT_MODELS:
        raise RuntimeError(f"Unsupported LLM_PROVIDER: {provider}")
    model = (os.getenv("LLM_MODEL") or "").strip() or DEFAULT_MODELS[provider]

    if provider == "anthropic":
        url = "https://api.anthropic.com/v1/messages"
        headers = {"x-api-key": key, "anthropic-version": "2023-06-01", "Content-Type": "application/json"}
        body = {"model": model, "max_tokens": 400, "messages": [{"role": "user", "content": prompt}]}
    else:
        url = (
            "https://api.openai.com/v1/chat/completions"
            if provider == "openai"
            else "https://api.groq.com/openai/v1/chat/completions"
        )
        headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
        if provider == "groq":
            headers["User-Agent"] = groq_user_agent()
        body = {"model": model, "messages": [{"role": "user", "content": prompt}]}

    request = urllib.request.Request(url, data=json.dumps(body).encode("utf-8"), headers=headers, method="POST")
    with urllib.request.urlopen(request, timeout=60) as response:
        data = json.loads(response.read().decode("utf-8"))
    if provider == "anthropic":
        return data["content"][0]["text"]
    return data["choices"][0]["message"]["content"]
