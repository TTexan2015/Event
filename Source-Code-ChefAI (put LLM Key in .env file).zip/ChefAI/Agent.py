# ChefAI step 1 — today's expenses
import asyncio
import json
import os
import re
import sys
import urllib.error
import urllib.request
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.name
MCP_DIR = ROOT / f"{PROJECT}-MCP"
SERVER_PATH = MCP_DIR / "server.py"
MAX_TOOL_CALLS = 6
DEMO_QUESTION = "Show last year's tomato spend."

if str(MCP_DIR) not in sys.path:
    sys.path.insert(0, str(MCP_DIR))

DEFAULT_MODELS = {
    "openai": "gpt-4o-mini",
    "anthropic": "claude-haiku-4-5",
    "groq": "openai/gpt-oss-20b",
}

ITEMS = [
    {"item": "Roma tomatoes", "vendor": "FreshFarm Produce", "qty": 12, "unit_price": 1.25},
    {"item": "Basil bunches", "vendor": "GreenLeaf Herbs", "qty": 6, "unit_price": 2.40},
    {"item": "Olive oil 1L", "vendor": "Mediterranean Oils Co", "qty": 2, "unit_price": 18.50},
    {"item": "Chicken breasts 5lb", "vendor": "Hillside Poultry", "qty": 3, "unit_price": 14.75},
    {"item": "Sourdough loaves", "vendor": "Dawn Bakery", "qty": 8, "unit_price": 4.10},
    {"item": "Heavy cream pints", "vendor": "Meadow Dairy", "qty": 4, "unit_price": 3.85},
]


def load_env_file():
    """Read <project root>/.env into os.environ; empty values are skipped."""
    env_path = Path(__file__).resolve().parent / ".env"
    try:
        lines = env_path.read_text(encoding="utf-8-sig").splitlines()
    except OSError:
        return
    for line in lines:
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        name, value = line.split("=", 1)
        name = name.strip()
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in ("'", '"'):
            value = value[1:-1]
        if name and value:
            os.environ[name] = value


def normalize_provider(value):
    provider = (value or "").strip().lower()
    if not provider:
        return "openai"
    if provider == "claude":
        return "anthropic"
    return provider


def groq_user_agent():
    safe = re.sub(r"[^A-Za-z0-9._-]", "", PROJECT)
    return f"{safe}/1.0" if safe else "PythonApp/1.0"


def call_llm(prompt):
    """Single routing helper for every LLM call: openai, anthropic, or groq."""
    key = os.getenv("LLM_API_KEY")
    if not key:
        raise RuntimeError("LLM_API_KEY is not set")
    provider = normalize_provider(os.getenv("LLM_PROVIDER"))
    if provider not in DEFAULT_MODELS:
        raise RuntimeError(f"Unsupported LLM_PROVIDER: {provider}")
    model = (os.getenv("LLM_MODEL") or "").strip() or DEFAULT_MODELS[provider]

    if provider == "anthropic":
        url = "https://api.anthropic.com/v1/messages"
        headers = {
            "x-api-key": key,
            "anthropic-version": "2023-06-01",
            "Content-Type": "application/json",
        }
        body = {"model": model, "max_tokens": 400, "messages": [{"role": "user", "content": prompt}]}
    else:
        url = (
            "https://api.openai.com/v1/chat/completions"
            if provider == "openai"
            else "https://api.groq.com/openai/v1/chat/completions"
        )
        headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
        if provider == "groq":
            headers["User-Agent"] = groq_user_agent()
        body = {"model": model, "messages": [{"role": "user", "content": prompt}]}

    request = urllib.request.Request(
        url, data=json.dumps(body).encode("utf-8"), headers=headers, method="POST"
    )
    with urllib.request.urlopen(request, timeout=60) as response:
        data = json.loads(response.read().decode("utf-8"))
    if provider == "anthropic":
        return data["content"][0]["text"]
    return data["choices"][0]["message"]["content"]


def load_skill():
    try:
        return (ROOT / "SKILL.md").read_text(encoding="utf-8")
    except OSError:
        return None


def format_expense_table(rows, total):
    """Apply the format-expense-table skill: formatting only, numbers untouched."""
    headers = ["Item", "Vendor", "Qty", "Unit price", "Line total"]
    body = [
        [r["item"], r["vendor"], str(r["qty"]), f"${r['unit_price']:.2f}", f"${r['line_total']:.2f}"]
        for r in rows
    ]
    total_row = ["TOTAL", "", "", "", f"${total:.2f}"]
    widths = [max(len(line[i]) for line in [headers, *body, total_row]) for i in range(5)]

    def fmt(line):
        cells = []
        for i, cell in enumerate(line):
            cells.append(cell.ljust(widths[i]) if i < 2 else cell.rjust(widths[i]))
        return " | ".join(cells)

    separator = "-+-".join("-" * w for w in widths)
    lines = [f"{PROJECT} — today's shipment (formatted)", fmt(headers), separator]
    lines += [fmt(line) for line in body]
    lines += [separator, fmt(total_row)]
    return "\n".join(lines)


def ask_chef(prompt, label="Chef says:"):
    if not os.getenv("LLM_API_KEY"):
        print("LLM skipped: LLM_API_KEY is not set in the .env file or the environment.")
        return
    try:
        answer = call_llm(prompt)
        print(label)
        print(answer.strip())
    except urllib.error.HTTPError as exc:
        print(f"LLM error: {exc.code} {exc.reason}")
    except Exception as exc:
        print(f"LLM error: {exc}")


# ---------------------------------------------------------------------------
# Step 3: CSV picker, MCP connection and the dynamic agent loop
# ---------------------------------------------------------------------------

PERIOD_PLAYBOOK = (
    "Period playbook (map the user's words to a period BEFORE any tool call; years come from the CSV facts):\n"
    "- A 4-digit year that exists in the CSV -> that full calendar year (pass the 4-digit year).\n"
    "- 'last year' / 'previous year' -> last_year (the calendar year before the latest year in the CSV).\n"
    "- 'this year' / 'year to date' / 'YTD' / 'all of <latest year>' -> year_to_date.\n"
    "- 'latest' / 'most recent delivery' / 'last delivery' -> latest_delivery.\n"
    "- vs / versus / compare / 'YEAR A vs YEAR B' = TWO query_expenses calls (one per year), then ONE comparison report. "
    'Never period="custom".\n'
    "- Never map a previous-year question to year_to_date. Never map a latest-year question to last_year.\n"
    "- Item filters are case-insensitive substrings and singular/plural both match "
    "(tomato matches Roma tomatoes, loaf matches Sourdough loaves)."
)


def import_csv_tools():
    try:
        from tools import csv_tools

        return csv_tools
    except Exception as exc:
        print(f"MCP tools folder could not be imported: {exc}")
        return None


def pick_csv(csv_tools):
    """Discover *.csv files, print the searched folders and let the user choose when there are several."""
    folder, files, searched = csv_tools.find_csvs()
    for path in searched:
        print(f"Searched for *.csv in: {path}")
    if not files:
        print("No CSV file was found. Folders searched: " + "; ".join(searched))
        return None
    print(f"CSV folder used: {folder}")
    if len(files) == 1:
        print(f"Using CSV: {files[0]}")
        return files[0]
    print("Several CSV files were found:")
    for number, path in enumerate(files, 1):
        print(f"  {number}. {path.name}  ({path})")
    while True:
        try:
            choice = input(f"Pick a CSV by number (1-{len(files)}): ").strip()
        except EOFError:
            print(f"No input available; using {files[0].name}")
            return files[0]
        if choice.isdigit() and 1 <= int(choice) <= len(files):
            print(f"Using CSV: {files[int(choice) - 1]}")
            return files[int(choice) - 1]
        print("That is not a valid number; please try again.")


def print_csv_summary(csv_tools):
    summary = csv_tools.csv_summary()
    if summary is None:
        return
    counts = summary["period_row_counts"]
    print(f"Chosen CSV: {summary['csv_path']}")
    print(f"Row count: {summary['row_count']}")
    print(f"Min date: {summary['min_date']}")
    print(f"Max date: {summary['max_date']}")
    print(f"Rows for latest delivery: {counts['latest_delivery']}")
    print(f"Rows for year to date: {counts['year_to_date']}")
    print(f"Rows for last year: {counts['last_year']}")


def first_line(text):
    for line in (text or "").splitlines():
        if line.strip():
            return line.strip()
    return ""


def schema_params(schema):
    props = (schema or {}).get("properties", {})
    required = set((schema or {}).get("required", []))
    parts = []
    for name, spec in props.items():
        kind = spec.get("type") or "/".join(str(s.get("type")) for s in spec.get("anyOf", [])) or "any"
        parts.append(f"{name}: {kind}" + ("" if name in required else " (optional)"))
    return ", ".join(parts)


def attr(obj, snake, camel, default=None):
    """Read an attribute under its mcp 2.x (snake_case) or 1.x (camelCase) name."""
    if hasattr(obj, snake):
        return getattr(obj, snake)
    return getattr(obj, camel, default)


def parse_tool_result(result):
    text = "".join(getattr(c, "text", "") for c in result.content if getattr(c, "type", "") == "text")
    if attr(result, "is_error", "isError", False):
        return {"error": text or "Tool call failed."}
    try:
        data = json.loads(text)
    except ValueError:
        data = {"result": text}
    return data if isinstance(data, dict) else {"result": data}


class StdioBackend:
    label = "MCP server over STDIO"

    def __init__(self, session):
        self.session = session

    async def list_tools(self):
        listing = await self.session.list_tools()
        return [
            {
                "name": t.name,
                "description": t.description or "",
                "params": schema_params(attr(t, "input_schema", "inputSchema")),
            }
            for t in listing.tools
        ]

    async def call_tool(self, name, arguments):
        return parse_tool_result(await self.session.call_tool(name, arguments))


class FallbackBackend:
    """Same tool functions, called in-process through tools.csv_tools / tools.invoice_tools."""

    label = "local tool functions (STDIO fallback)"

    def __init__(self):
        import inspect

        import server

        self.inspect = inspect
        self.functions = {f.__name__: f for f in server.TOOL_FUNCTIONS}

    async def list_tools(self):
        return [
            {
                "name": name,
                "description": func.__doc__ or "",
                "params": str(self.inspect.signature(func)),
            }
            for name, func in self.functions.items()
        ]

    async def call_tool(self, name, arguments):
        try:
            data = await asyncio.to_thread(self.functions[name], **arguments)
        except Exception as exc:
            return {"error": f"{type(exc).__name__}: {exc}"}
        return data if isinstance(data, dict) else {"result": data}


def parse_json_reply(text):
    text = (text or "").strip()
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text)
    try:
        return json.loads(text)
    except ValueError:
        start, end = text.find("{"), text.rfind("}")
        if start != -1 and end > start:
            try:
                return json.loads(text[start : end + 1])
            except ValueError:
                return None
    return None


def show_result(result, limit=3000):
    text = json.dumps(result, indent=2, default=str)
    print(text if len(text) <= limit else text[:limit] + "\n... (truncated)")


def csv_facts(csv_tools):
    info = csv_tools.csv_info() if csv_tools else None
    if not info:
        return "CSV facts: no CSV file is loaded."
    return (
        f"CSV facts: file {info['csv_path']}; columns {', '.join(info['columns'])}; {info['row_count']} rows; "
        f"min date {info['min_date']}; max date {info['max_date']}; years present {info['years_present']}."
    )


def build_loop_prompt(question, tools, facts, history, *, require_report, plan, style, final):
    tool_lines = "\n".join(
        f"- {t['name']}({t['params']}): {' '.join((t['description'] or '').split())}" for t in tools
    )
    lines = [
        f"You are the planner for the {PROJECT} kitchen expense assistant. You can act only by choosing MCP tools.",
        "Live MCP tools:",
        tool_lines,
        "",
        facts,
        PERIOD_PLAYBOOK,
        "",
        f"Question: {question}",
    ]
    if plan is not None:
        lines += ["", "Query plan you wrote earlier (follow it step by step): " + json.dumps(plan)]
    lines += ["", "Tool calls so far:"]
    if not history:
        lines.append("(none yet)")
    for entry in history:
        if "note" in entry:
            lines.append("NOTE: " + entry["note"])
        else:
            lines.append(
                f"- {entry['tool']} {json.dumps(entry['arguments'])} -> "
                + json.dumps(entry["result"], separators=(",", ":"), default=str)
            )
    lines += [
        "",
        "Reply with JSON only, no prose and no code fences. Either",
        '{"tool":"<exact tool name from the list>","arguments":{...},"done":false}',
        "or",
        '{"done":true,"answer":"<short user-facing answer using only numbers from tool results>"}',
        "Rules: never invent numbers; use only values from tool results. After a successful query_expenses or "
        "generate_invoice, prefer done=true unless a different tool is still required.",
    ]
    if require_report:
        lines.append(
            "A report or invoice HTML file must be written (generate_report or generate_invoice) before you may set done=true, "
            "unless the CSV cannot satisfy the request and tool errors say so."
        )
    lines.append(
        "When you call generate_report, always pass title, mode and queries (a list of {\"period\":...,\"item\":...} "
        "mirroring every query_expenses call the report must contain)."
    )
    if final:
        lines.append("All needed tool calls are finished. Reply now with done=true and the answer.")
    lines.append(f"Answer style: {style}")
    return "\n".join(lines)


async def llm_async(prompt):
    return await asyncio.to_thread(call_llm, prompt)


async def agent_loop(backend, csv_tools, question, *, require_report=False, plan=None, style="one short sentence"):
    """LLM-driven loop: the LLM picks every MCP tool; Python only executes the chosen tool."""
    tools = await backend.list_tools()
    print("MCP tools available (live):")
    for t in tools:
        print(f"  - {t['name']}: {first_line(t['description'])}")
    print(f"Question: {question}")
    outcome = {"answer": None, "files": [], "error": None}
    if not os.getenv("LLM_API_KEY"):
        outcome["error"] = "LLM skipped: LLM_API_KEY is not set in the .env file or the environment."
        print(outcome["error"])
        return outcome

    names = {t["name"] for t in tools}
    facts = csv_facts(csv_tools)
    history, succeeded = [], set()
    tool_calls = turns = errors = 0
    last_error = None
    needs_closing = False

    while tool_calls < MAX_TOOL_CALLS and turns < MAX_TOOL_CALLS * 2:
        turns += 1
        prompt = build_loop_prompt(
            question, tools, facts, history, require_report=require_report, plan=plan, style=style, final=False
        )
        try:
            reply = await llm_async(prompt)
        except urllib.error.HTTPError as exc:
            outcome["error"] = f"LLM error: {exc.code} {exc.reason}"
            break
        except Exception as exc:
            outcome["error"] = f"LLM error: {exc}"
            break
        decision = parse_json_reply(reply)
        if not isinstance(decision, dict):
            history.append({"note": "Your last reply was not valid JSON. Reply with JSON only."})
            continue

        if decision.get("done"):
            if require_report and not outcome["files"] and errors < 2:
                history.append(
                    {"note": "You cannot finish yet: no HTML file exists. Call generate_report (or generate_invoice) next."}
                )
                continue
            outcome["answer"] = str(decision.get("answer") or "").strip() or None
            break

        tool, arguments = decision.get("tool"), decision.get("arguments") or {}
        if tool not in names or not isinstance(arguments, dict):
            print(f"LLM chose an unknown tool or bad arguments: {tool!r}")
            history.append({"note": f"{tool!r} is not a valid tool call. Choose one of: {', '.join(sorted(names))}."})
            continue
        print(f"LLM chose tool: {tool}")
        print(f"Arguments: {json.dumps(arguments)}")

        key = (tool, json.dumps(arguments, sort_keys=True))
        if key in succeeded:
            if require_report and not outcome["files"]:
                history.append({"note": "That exact call already succeeded. Choose the next tool (the report)."})
                continue
            needs_closing = True
            break

        tool_calls += 1
        result = await backend.call_tool(tool, arguments)
        print("Result:")
        show_result(result)
        history.append({"tool": tool, "arguments": arguments, "result": result})
        if result.get("error"):
            errors += 1
            last_error = result["error"]
            continue
        succeeded.add(key)
        if result.get("file_path"):
            outcome["files"].append(result["file_path"])
            needs_closing = True
            break
    else:
        needs_closing = bool(history)

    if outcome["answer"] is None and outcome["error"] is None and needs_closing:
        try:
            reply = await llm_async(
                build_loop_prompt(
                    question, tools, facts, history, require_report=False, plan=plan, style=style, final=True
                )
            )
            decision = parse_json_reply(reply)
            if isinstance(decision, dict) and decision.get("answer"):
                outcome["answer"] = str(decision["answer"]).strip()
        except Exception as exc:
            outcome["error"] = f"LLM error: {exc}"
    if outcome["answer"] is None and outcome["files"]:
        outcome["answer"] = f"Done. File written: {outcome['files'][-1]}"
    if require_report and not outcome["files"] and last_error and not outcome["error"]:
        outcome["error"] = f"No report was written. Reason from the tool result: {last_error}"
    if outcome["answer"] is None and outcome["error"] is None:
        outcome["error"] = "The loop ended without an answer."
    if outcome["error"]:
        print(outcome["error"])
    return outcome


async def ainput(prompt):
    return await asyncio.to_thread(input, prompt)


async def custom_report(backend, csv_tools):
    print("Which report would you like to generate now?")
    request = (await ainput("> ")).strip()
    if not request:
        print("No report requested.")
        return
    print("Consulting the LLM about this report…")
    if not os.getenv("LLM_API_KEY"):
        print("LLM skipped: LLM_API_KEY is not set in the .env file or the environment.")
        return

    tools = await backend.list_tools()
    info = csv_tools.csv_info() if csv_tools else None
    if info:
        data_facts = (
            f"CSV columns: {', '.join(info['columns'])}\n"
            f"Min date: {info['min_date']}  Max date: {info['max_date']}  Years present: {info['years_present']}\n"
            f"Sample rows: {json.dumps(info['sample_rows'])}\n"
            f"Distinct items: {json.dumps(info['items'])}\n"
            f"Distinct vendors: {json.dumps(info['vendors'])}"
        )
    else:
        data_facts = "No CSV is loaded."
    tool_lines = "\n".join(
        f"- {t['name']}({t['params']}): {' '.join((t['description'] or '').split())}" for t in tools
    )
    prompt = (
        f"You are planning a custom expense report for {PROJECT}. Do NOT answer the request yet; write a QUERY PLAN.\n"
        f"User request (verbatim): {request}\n\n"
        f"Live MCP tools:\n{tool_lines}\n\n{data_facts}\n\n{PERIOD_PLAYBOOK}\n\n"
        "Reply with JSON only, no prose and no code fences, for example:\n"
        '{"intent":"compare|spend|items|qty_price|vendor|other","needs_multiple_queries":true,'
        '"queries":[{"tool":"query_expenses","arguments":{"period":"...","item":null}}],'
        '"then_report":{"tool":"generate_report","arguments":{"title":"...","mode":"compare",'
        '"queries":[{"period":"...","item":null}]}}}\n'
        "mode is one of summary, compare, qty_price, vendor. Use only periods and items the CSV can satisfy."
    )
    plan = None
    try:
        plan = parse_json_reply(await llm_async(prompt))
    except urllib.error.HTTPError as exc:
        print(f"LLM error: {exc.code} {exc.reason}")
        return
    except Exception as exc:
        print(f"LLM error: {exc}")
        return
    if isinstance(plan, dict):
        print("Query plan:")
        show_result(plan)
    else:
        plan = None
        print("The LLM did not return a usable query plan; continuing with the request directly.")

    outcome = await agent_loop(
        backend,
        csv_tools,
        request,
        require_report=True,
        plan=plan,
        style="one or two short sentences describing the report, using only numbers from tool results",
    )
    if outcome["answer"]:
        print(f"Answer: {outcome['answer']}")
    for path in outcome["files"]:
        print(f"HTML file: {path}")


async def expense_question(backend, csv_tools):
    print("Type your question about the expenses, shipments or totals:")
    question = (await ainput("> ")).strip()
    if not question:
        print("No question entered.")
        return
    outcome = await agent_loop(
        backend,
        csv_tools,
        question,
        style=(
            "a chef-style reply of one to three sentences using only numbers from tool results "
            "(for vendor counts use vendor_count or the vendors list)"
        ),
    )
    if outcome["answer"]:
        print("Chef says:")
        print(outcome["answer"])


async def interactive_menu(backend, csv_tools):
    print()
    print("=" * 60)
    print("Interactive mode — choose an option")
    print("=" * 60)
    print()
    while True:
        print("1. Generate a custom invoice")
        print("2. Ask a question about expenses")
        print("3. Exit")
        try:
            choice = (await ainput("Enter your choice: ")).strip()
        except EOFError:
            choice = "3"
        print()
        if choice == "1":
            await custom_report(backend, csv_tools)
        elif choice == "2":
            await expense_question(backend, csv_tools)
        else:
            print("Goodbye! Happy cooking.")
            return
        print()


async def run_flow(backend, csv_tools):
    print(f"Connected via {backend.label}.")
    invoice_questions = [
        "Generate the latest-delivery invoice.",
        "Generate the year-to-date invoice.",
        "Generate the last-year invoice.",
    ]
    for question in invoice_questions:
        print()
        outcome = await agent_loop(backend, csv_tools, question, require_report=True)
        if outcome["answer"]:
            print(f"Answer: {outcome['answer']}")
        for path in outcome["files"]:
            print(f"HTML file: {path}")

    print("=" * 60)
    print("Dynamic agent loop — LLM picks the MCP tool.")
    outcome = await agent_loop(
        backend,
        csv_tools,
        DEMO_QUESTION,
        style="exactly two sentences a chef would say, using only numbers from the tool result",
    )
    if outcome["answer"]:
        print("Chef says (loop):")
        print(outcome["answer"])

    await interactive_menu(backend, csv_tools)


async def run_mcp_section():
    print("=" * 60)
    print("Now looking into the MCP server to generate expense invoices.")
    csv_tools = import_csv_tools()
    if csv_tools is None:
        return
    chosen = pick_csv(csv_tools)
    if chosen:
        os.environ["CHEFAI_CSV_PATH"] = str(chosen)
        print_csv_summary(csv_tools)

    started = False
    try:
        from mcp import ClientSession, StdioServerParameters
        from mcp.client.stdio import stdio_client

        params = StdioServerParameters(
            command=sys.executable, args=[str(SERVER_PATH)], env=dict(os.environ), cwd=str(MCP_DIR)
        )
        with open(os.devnull, "w") as quiet:
            async with stdio_client(params, errlog=quiet) as (read, write):
                async with ClientSession(read, write) as session:
                    await asyncio.wait_for(session.initialize(), 30)
                    started = True
                    await run_flow(StdioBackend(session), csv_tools)
        return
    except Exception as exc:
        if started:
            print(f"MCP session error: {type(exc).__name__}: {exc}")
            return
        print(f"STDIO connection failed ({type(exc).__name__}: {exc}); using the local tool functions instead.")
    try:
        await run_flow(FallbackBackend(), csv_tools)
    except Exception as exc:
        print(f"MCP fallback error: {type(exc).__name__}: {exc}")


def main():
    load_env_file()

    total = 0.0
    rows = []
    for entry in ITEMS:
        line_total = entry["qty"] * entry["unit_price"]
        total += line_total
        rows.append({**entry, "line_total": line_total})

    print(f"{PROJECT} — today's shipment")
    table_lines = []
    for r in rows:
        table_lines.append(
            f"{r['item']} | {r['vendor']} | {r['qty']} | ${r['unit_price']:.2f} | ${r['line_total']:.2f}"
        )
    for text in table_lines:
        print(text)
    print(f"TODAY TOTAL: ${total:.2f}")

    print()
    print("=" * 60)
    print("Applying the skill now.")
    print("=" * 60)
    print()

    skill_text = load_skill()
    if skill_text is None:
        print("SKILL.md not found next to Agent.py; skipping the formatted table.")
    else:
        formatted = format_expense_table(rows, total)
        print(formatted)
        print()
        ask_chef(
            "Here is today's shipment as a formatted table:\n"
            f"{formatted}\n\n"
            "This is the formatting skill that was applied:\n"
            f"{skill_text}\n\n"
            "In two sentences, say what a chef would say about today's delivery spend. "
            "Use only the numbers in the table; do not change or invent totals."
        )

    try:
        asyncio.run(run_mcp_section())
    except KeyboardInterrupt:
        print("\nInterrupted. Goodbye.")
    except Exception as exc:
        print(f"MCP section error: {type(exc).__name__}: {exc}")


if __name__ == "__main__":
    main()
