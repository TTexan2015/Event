# Skill

- Name: format-expense-table
- When to use: after today's expenses are totaled
- Rules: do not change the numbers; only format

## Format

- Title line: ChefAI — today's shipment (formatted)
- Columns: Item | Vendor | Qty | Unit price | Line total
- Right-align Qty and money columns
- Money as $X.XX
- Header row, dash separator, one row per item, then a TOTAL row with the grand total in the last column
